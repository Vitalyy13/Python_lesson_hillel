class Group:
    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student):
        self.group.add(student)

    def find_student(self, last_name):
        for student in self.group:
            if student.last_name == last_name:
                return student
        return None

    def delete_student(self, last_name):
        student = self.find_student(last_name)
        if student is not None:
            self.group.discard(student)

    def __str__(self):
        students_lines = ""
        for student in self.group:
            students_lines += str(student) + "\n"
        return f"Number: {self.number}\n{students_lines}"
